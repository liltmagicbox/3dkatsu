from argsparse import argsparse3
import glm

from glm import vec3,vec4
from glm import mat4

from glm import normalize

from glm import cos,sin, radians,tan, acos
from glm import cross, dot

from glm import perspective, translate, rotate, scale




def quatel(axis,th):
    axis = normalize(axis)
    x,y,z = axis *sin(th/2)
    w = cos(th/2)
    return x,y,z,w

def mrotel(qx,qy,qz,qw):    
    mat = [
    [1 - 2*qy**2 - 2*qz**2,   2*qx*qy - 2*qz*qw,   2*qx*qz + 2*qy*qw, 0],
    [2*qx*qy + 2*qz*qw,   1 - 2*qx**2 - 2*qz**2,   2*qy*qz - 2*qx*qw, 0],
    [2*qx*qz - 2*qy*qw,   2*qy*qz + 2*qx*qw,   1 - 2*qx**2 - 2*qy**2, 0],
    [0,0,0,1]
    ]
    return mat

def rotmat_old(axis,th):
    x,y,z,w=quatel(axis,th)
    return mrotel(x,y,z,w)    




def rotmat(axis,th):
    model = glm.mat4(1.0)
    return glm.rotate(model, th, axis)

def modelmat(posx,scale, axis,th):
    model = glm.mat4(1.0)
    model = glm.translate(model, glm.vec3(posx, 0.0, 0.0))
    model = glm.scale(model, glm.vec3(scale, scale, scale))    
    return glm.rotate(model, th, axis)


if __name__ == '__main__':    
    v1=vec3(1,2,3)
    v2=vec3(3,2,5)

    n = normalize(v1)
    c = cross(v1,v2)
    d = dot(v1,v2)    
    print(n)
    print(c)
    print(d)
    r = rotmat( c,30)
    print(r)
    m = modelmat(30,2, c,30)
