def vec3(x,y,z):
    return Vector(x,y,z)
def pos(x,y,z):
    return Vector(x,y,z,1.0)
def mna(x,y,z):
    return Vector(x,y,z,0.0)


class V:
    def __init__(self,x,y,z):
        self.data = [x,y,z]

    def __getattribute__(self,name):
        if name == 'x':
            return self.data[0]
        elif name == 'y':
            return self.data[1]
        elif name == 'z':
            return self.data[2]
        return super().__getattribute__(name)
    def __setattr__(self, name, value):
        if name == 'x':
            self.data[0] = value
        elif name == 'y':
            self.data[1] = value
        elif name == 'z':
            self.data[2] = value
        super().__setattr__(name, value)

    def __repr__(self):
        return self.data
    def __str__(self):
        return 'Vector '+str(self.data)
    def __add__(self,target):
        a = self.data
        b = target.data
        return [a[0]+b[0], a[1]+b[1], a[2]+b[2]]
    def __sub__(self,target):
        a = self.data
        b = target.data
        return [a[0]-b[0], a[1]-b[1], a[2]-b[2]]

        
v = V(1,2,3)
print(v)
v.x=5
print(v.x)

vv = V(8,8,8)
print(v+vv)
#v+=[5,5,5] # i want do this..way? no!
v+= V(5,5,5)
print(v)



print('*'*20,'timetest')
from time import time

ITER = 100000

vvv=[1.0,2.0,3.0]
#==================took 14ms.
t=time()
for i in range(ITER):
    vvv = [ vvv[0]+5.1,vvv[1]+4.2,vvv[2]+3.3]
print(time()-t)

#==================took 114ms. ANYWAY DON'T DO LIKE THIS.. HEAVY EVEN ADD!
v = V(1.0,2.0,3.0)
t=time()
for i in range(ITER):
    #v+= V(5.1,4.2,3.3)
    v + V(5.1,4.2,3.3)
print(time()-t)


#=========================== took 340ms! hahaha!
from np_modelmat_faster import npVector
v = npVector(1,2,3)
t=time()
for i in range(ITER):
    #v += (5.1,4.2,3.3) #340ms
    v += npVector(5.1,4.2,3.3) #even 740ms!!
print(time()-t)

#=============conculusion:
# pure py list took 2ms for 10000, 0.2ms for 1000. that's fine.
# any other thing took 10ms kinds. too, toobad.

class vec3(list):
    def __init__(self, x,y,z):        
        super().__init__( (x,y,z) )

    def __str__(self):
        return "Vector "+super().__str__()

    def __add__(self,other):
        return [self[0]+other[0], self[1]+other[1] ,self[2]+other[2]]
    def __mul__(self,x):
        return [self[0]*x, self[1]*x ,self[2]*x]

#----errors, dont use it. atleast it can't be changed..
class tuplevec3(tuple):
    def __init__(self, x,y,z):
        super().__init__( x,y,z )


print('phase2....as fast you can')

vvv=(1.0,2.0,3.0)
#==========took 12ms.
t=time()
for i in range(ITER):
    vvv = ( vvv[0]+5.1,vvv[1]+4.2,vvv[2]+3.3)
print(time()-t, 'tuple + tuple')

vvv=[1.0,2.0,3.0]
#==========took 14ms.
t=time()
for i in range(ITER):
    vvv = [ vvv[0]+5.1,vvv[1]+4.2,vvv[2]+3.3]
print(time()-t, 'list + list')


#---------7ms! Vector tuple faster!
v = vec3(1,2,3)
t=time()
for i in range(ITER):
    v+= ( 5.1,4.2,3.3)
print(time()-t,' Vector + tuple')

#----------10ms
v = vec3(1,2,3)
t=time()
for i in range(ITER):
    v+= [5.1,4.2,3.3]
print(time()-t,' Vector + list')


#------40ms
v = vec3(1,2,3)
t=time()
for i in range(ITER):
    v+= vec3( 5.1,4.2,3.3)
print(time()-t, ' Vector + Vector')



print('phase3....as fast you can')

#---------7ms! Vector tuple faster!
v = vec3(1,2,3)
t=time()
for i in range(ITER):
    v+= ( 5.1,4.2,3.3)
print(time()-t,' Vector + tuple')

#----------2ms, max speed! WOW! : 100,000 iter just took 2ms. haha..
v = vec3(1,2,3)
t=time()
for i in range(ITER):
    1
print(time()-t)


print('glmglmglkmglglm')
from glm import vec3 as gv3

#------------ took.... 15ms!
v = gv3(1,2,3)
t=time()
for i in range(ITER):
    v+=(1,2,3)
print(time()-t)


#------------ took.... 19ms!
v = gv3(1,2,3)
t=time()
for i in range(ITER):
    v+=[1,2,3]
print(time()-t,'isreally 19')

#------------ took.... 19ms!
v = gv3(1,2,3)
t=time()
for i in range(ITER):
    v+=gv3(1,2,3)
print(time()-t)

#------------ took.... 7ms! it's new score.. understood why.
v = gv3(1,2,3)
vv = gv3(1,2,3)
t=time()
for i in range(ITER):
    v+=vv
print(time()-t)

#----------see, list vector took 12ms, 2times slower.
v = vec3(1,2,3)
vv = vec3(1,2,3)
t=time()
for i in range(ITER):
    v+=vv
print(time()-t)

#------what?? it took 10ms. . as fast.
v = vec3(1,2,3)
t=time()
for i in range(ITER):
    v+=(1,2,3)
print(time()-t,'what')



#------gravity by dt.. took same speed.. .. actually quite slow!
#------------------10ms
g = gv3(0,0,-9.8)
speed = gv3(0,0,0)
t=time()
for i in range(ITER):
    speed+= g*0.01
print(time()-t)

#----16ms/??huh..
g = gv3(0,0,-9.8)
speed = gv3(0,0,0)
dt = vec3(0.01,0.01,0.01)
t=time()
for i in range(ITER):
    speed+= g*dt
print(time()-t)


#------7ms.
v = vec3(1,2,3)
t=time()
for i in range(ITER):
    v[2] += -9.8*0.01
print(time()-t)

#------29ms... extreamly slow!
v = vec3(1,2,3)
g = vec3(0,0,-9.8)
t=time()
for i in range(ITER):
    v += g*0.01
print(time()-t)

#------23ms... how??huh..
v = vec3(1,2,3)
g = vec3(0,0,-9.8)
t=time()
for i in range(ITER):
    v += g[0]*0.01,g[1]*0.01,g[2]*0.01
print(time()-t)


#------maybe faster muladd. but took 25ms, not fast.wow.
v = vec3(1,2,3)
g = vec3(0,0,-9.8)
t=time()
for i in range(ITER):
    v = v[0]+g[0]*0.01, v[1]+g[1]*0.01,v[2]+g[2]*0.01
print(time()-t)


#----17ms. we found, python float mul too slow.
v = vec3(1,2,3)
g = vec3(0,0,-9.8)
t=time()
for i in range(ITER):
    a = g[0]*0.01,g[1]*0.01,g[2]*0.01
print(time()-t)

#---------------12ms, still slow.. or  fast enough.
#  if +=, it  became 17ms. ..actially same speed g[0]!
#---think every loop it take data from 'x' object.
v = vec3(1,2,3)
g = vec3(0,0,-9.8)
x,y,z = g[0],g[1],g[2]
t=time()
for i in range(ITER):
    v += x*0.01,y*0.01,z*0.01
print(time()-t)



#-------------8ms. why? maybe it's just tuple..
v = vec3(1,2,3)
g = vec3(0,0,-9.8)
t=time()
for i in range(ITER):
    v += 0.1*0.01,0.1*0.01,0.1*0.01
print(time()-t)

#-----------------------4MS. so fast..
v = vec3(1,2,3)
g = vec3(0,0,-9.8)
t=time()
for i in range(ITER):
    a = 0.1*0.01,0.1*0.01,0.1*0.01
print(time()-t)




